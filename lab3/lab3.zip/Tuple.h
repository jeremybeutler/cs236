#ifndef TUPLE_H
#define TUPLE_H

#include <string>
#include <sstream>
#include <vector>

class Tuple : public std::vector<std::string>
{
public:
    Tuple() {}
};

#endif // TUPLE_H
