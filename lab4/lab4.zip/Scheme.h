#ifndef SCHEME_H
#define SCHEME_H

#include <string>
#include <sstream>
#include <vector>

class Scheme : public std::vector<std::string>
{
public:
    Scheme() {}
};

#endif // SCHEME_H
